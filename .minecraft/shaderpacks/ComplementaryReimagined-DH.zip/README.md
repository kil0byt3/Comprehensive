# Complementary (Distant Horizons compatibility fork)

DISCLAIMER: THIS IS FOR LEGACY IRIS + DH COMPATIBILITY. This is NOT for Iris + DH compatibility `v2`.  
For a version of Complementary that is compatible with Iris + DH compatibility `v2`, see Emin's Patreon (`emingt`) and the Iris Discord server for a guide/an FAQ. Keep in mind that no support will be provided by the Iris Discord server.
